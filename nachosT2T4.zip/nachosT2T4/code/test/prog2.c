//----------------------------------------
// test prog2.c for assignment3
// Author: Haiyang Sun
// Date: 2018/11/25
//----------------------------------------
#include "syscall.h"

int
main()
{
    
	char* message;
	Register(6);
	Receive(6);
	
        
	Exit(0);
}
