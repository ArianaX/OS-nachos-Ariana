//----------------------------------------
// test prog1.c for assignment3
// Author: Xiang Li
// Date: 2018/11/28
//----------------------------------------
#include "syscall.h"

int
main()
{

	char* message = "Hello from tprog3 to tprog2";
	Register(7);
	Send(message, 27, 6);

	Exit(0);
}
