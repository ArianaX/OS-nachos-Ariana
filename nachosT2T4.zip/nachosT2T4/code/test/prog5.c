//----------------------------------------
// test prog1.c for assignment3
// Author: Xiang Li
// Date: 2018/11/25
//----------------------------------------
#include "syscall.h"

int
main()
{
    
	char* message = "Hello from tprog5 to tprog2";
	Register(9);
	Send(message, 27, 6);
        
	Exit(0);
}
