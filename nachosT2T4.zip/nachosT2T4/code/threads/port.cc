// //------------------------------------------------------
// // This is the Port class implementation for Assignment3
// // Author: Haiyang Sun
// // Date: 2018/11/25
// //------------------------------------------------------
// #include "port.h"

// void Port::setMsg(string msg){
//     message = msg;
// }

// // string Port::getMsg(){
// //     return message;
// // }

// vector<Thread*> Port::getSendThreads(){
//     return sendThreads;
// }

// void Port::addSendThread(Thread* t){
//     sendThreads.push_back(t);
// }

// // Thread* Port::getReceiveThread(){
// //     return receiveThread;
// // }

// void Port::setReceiveThread(Thread* t){
//     receiveThread = t;
// }