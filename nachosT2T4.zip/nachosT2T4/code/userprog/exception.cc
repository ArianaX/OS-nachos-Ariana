// exception.cc
//  Entry point into the Nachos kernel from user programs.
//  There are two kinds of things that can cause control to
//  transfer back to here from user code:
//
//  syscall -- The user code explicitly requests to call a procedure
//  in the Nachos kernel.  Right now, the only function we support is
//  "Halt".
//
//  exceptions -- The user code does something that the CPU can't handle.
//  For instance, accessing memory that doesn't exist, arithmetic errors,
//  etc.
//
//  Interrupts (which can also cause control to transfer from user
//  code into the Nachos kernel) are handled elsewhere.
//
// For now, this only handles the Halt() system call.
// Everything else core dumps.
//
// Copyright (c) 1992-1996 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation
// of liability and disclaimer of warranty provisions.

#include "copyright.h"
#include "main.h"
#include "syscall.h"
#include "ksyscall.h"

//#include<stdlib.h>
#include "../threads/thread.h"
//ariana
#include <unordered_map>
#include<iostream>
#include<queue>
using namespace std;
unordered_map<int, Thread*> mapChildParent;
//----------------------------------------------------------------------
// ExceptionHandler
//  Entry point into the Nachos kernel.  Called when a user program
//  is executing, and either does a syscall, or generates an addressing
//  or arithmetic exception.
//
//  For system calls, the following is the calling convention:
//
//  system call code -- r2
//    arg1 -- r4
//    arg2 -- r5
//    arg3 -- r6
//    arg4 -- r7
//
//  The result of the system call, if any, must be put back into r2.
//
// If you are handling a system call, don't forget to increment the pc
// before returning. (Or else you'll loop making the same system call forever!)
//
//  "which" is the kind of exception.  The list of possible exceptions
//  is in machine.h.
//----------------------------------------------------------------------
void
RunUserProgram(void *filename) {
	AddrSpace *space = new AddrSpace;
	ASSERT(space != (AddrSpace *)NULL);
	if (space->Load((char*)filename)) {  // load the program into the space
		space->Execute();         // run the program
	}
	ASSERTNOTREACHED();
}
//ariana
void Exit_POS(int id) {
	cout << "This is Exit_POS function!" << endl;
	IntStatus oldLevel;
	if (id >= 1 && id <= 3) {
		Thread* cctemp = mapChildParent[id];
		oldLevel = kernel->interrupt->SetLevel(IntOff);
		if (cctemp != NULL) {
			kernel->scheduler->ReadyToRun(cctemp);
		}
		mapChildParent.erase(id);
		if (mapChildParent.size() == 0)
			cout << "all child thread has finished, now it is the main thread!!!!" << endl;
	}
	else
		cout << "Wrong childID in Exit_POS()" << endl;
	//kernel->currentThread->Finish();
	kernel->currentThread->Sleep(true);

	(void)kernel->interrupt->SetLevel(oldLevel);
	//kernel->currentThread->Yield();
	cout << "end of Exit_POS" << endl;
}


static void ForkTest1(int id)
{
	printf("ForkTest1 is called, its PID is %d\n", id);
	for (int i = 0; i < 3; i++)
	{
		printf("ForkTest1 is in loop %d\n", i);
		for (int j = 0; j < 100; j++)
			kernel->interrupt->OneTick();
	}
	Exit_POS(id);
}

static void ForkTest2(int id)
{
	printf("ForkTest2 is called, its PID is %d\n", id);
	for (int i = 0; i < 3; i++)
	{
		printf("ForkTest2 is in loop %d\n", i);
		for (int j = 0; j < 100; j++)
			kernel->interrupt->OneTick();
	}
	Exit_POS(id);
}

static void ForkTest3(int id)
{
	printf("ForkTest3 is called, its PID is %d\n", id);
	for (int i = 0; i < 3; i++)
	{
		printf("ForkTest3 is in loop %d\n", i);
		for (int j = 0; j < 100; j++)
			kernel->interrupt->OneTick();
	}
	Exit_POS(id);
}

int SysForkPos(int id) {
	//kernel->interrupt->SetLevel(IntOff);//AA
	Thread *t = new Thread("forked thread--ass2");
	switch (id) {
	case 1:
		t->Fork((VoidFunctionPtr)ForkTest1, (void *)1);
		cout << "111" << endl;
		return 1;
		break;
	case 2:
		t->Fork((VoidFunctionPtr)ForkTest2, (void *)2);
		cout << "222" << endl;
		return 2;
		break;
	case 3:
		t->Fork((VoidFunctionPtr)ForkTest3, (void *)3);
		cout << "333" << endl;
		return 3;
		break;
	default:
		cout << "wrong input, we create a child thread:100 here." << endl;
		return 100;
		break;

	}
}


void ExceptionHandler(ExceptionType which)
{
  int type = kernel->machine->ReadRegister(2);
  
  DEBUG(dbgSys, "Received Exception " << which << " type: " << type << "\n");
  int sizeAn,value,addrAn;

  switch (which) {
    case SyscallException:
      switch(type) {
	  case SC_Register:
	  {
		  DEBUG(dbgSys, "SC_Register" << kernel->machine->ReadRegister(4) << "\n");
		  int portNumber = (int)kernel->machine->ReadRegister(4);
		  if (kernel->mach_ports[portNumber].getReceiveThread() == NULL) {
			  kernel->mach_ports[portNumber].setReceiveThread(kernel->currentThread);
		  }

		  /* Modify return point */
		  {
			  /* set previous programm counter (debugging only)*/
			  kernel->machine->WriteRegister(PrevPCReg, kernel->machine->ReadRegister(PCReg));

			  /* set programm counter to next instruction (all Instructions are 4 byte wide)*/
			  kernel->machine->WriteRegister(PCReg, kernel->machine->ReadRegister(PCReg) + 4);

			  /* set next programm counter for brach execution */
			  kernel->machine->WriteRegister(NextPCReg, kernel->machine->ReadRegister(PCReg) + 4);
		  }
		  return;

		  ASSERTNOTREACHED();
	  }break;

	  case SC_Send:
	  {
		  cout << "-------------------------------------------" << endl;
		  cout << "now in SC_Send" << endl;
		  DEBUG(dbgSys, "SC_Send" << kernel->machine->ReadRegister(4) << "\n");
		  int msg_buf = (int)kernel->machine->ReadRegister(4);
		  int size = (int)kernel->machine->ReadRegister(5);
		  int portNumber = (int)kernel->machine->ReadRegister(6);
		  string message = "";
		  for (int i = 0; i < size; i++) {
			  int current;
			  kernel->machine->ReadMem(msg_buf + i, 1, &current);
			  message.push_back((char)current);
		  }
		  bool flag = false;
		  for(int i = 0; i < kernel->mach_ports[portNumber].getSendThreads().size(); i++){
			  if( kernel->mach_ports[portNumber].getSendThreads()[i] == kernel->currentThread){
				  flag = true;
				  break;
			  }
		  }
		  if(flag == false){
			  cout<<"portNumber is: "<<portNumber<<endl;
			  kernel->mach_ports[portNumber].addSendThread(kernel->currentThread);
			  cout << "add current thread into port[]"<<endl;
		  }

		  cout << "portNumber is: " << portNumber << endl;
		  kernel->mach_ports[portNumber].addSendThread(kernel->currentThread);
		  kernel->mach_ports[portNumber].setMsg(message);


		  Message msg;
		  msg.setMsgBody(message);
		  msg.setPort(portNumber);
		  kernel->msg_queue.push(msg);

		  /* Modify return point */
		  {
			  /* set previous programm counter (debugging only)*/
			  kernel->machine->WriteRegister(PrevPCReg, kernel->machine->ReadRegister(PCReg));

			  /* set programm counter to next instruction (all Instructions are 4 byte wide)*/
			  kernel->machine->WriteRegister(PCReg, kernel->machine->ReadRegister(PCReg) + 4);

			  /* set next programm counter for brach execution */
			  kernel->machine->WriteRegister(NextPCReg, kernel->machine->ReadRegister(PCReg) + 4);
		  }
		  return;

		  ASSERTNOTREACHED();
	  }
	  break;


	  case SC_Receive:
	  {
		  cout << "------------------------" << endl;
		  cout << "now in SC_Recieve" << endl;
		  DEBUG(dbgSys, "SC_Receive" << kernel->machine->ReadRegister(4) << "\n");
		  int portNumber = (int)kernel->machine->ReadRegister(4);
		  if (kernel->mach_ports[portNumber].getReceiveThread() != kernel->currentThread) {
			  cout << "no receive permission" << endl;
			  break;
		  }
		  if (kernel->mach_ports[portNumber].getMsg().size() == 0) {// == ""
			  cout << "this port has no massage inside" << endl;
			  kernel->currentThread->Yield();
		  }
		  //Ariana
		  int timesEmptyMessage = 0;

		  while (timesEmptyMessage<=1) {
			  vector<string> message = kernel->mach_ports[portNumber].getMsg();
			  if (message.size() == 0)
				  timesEmptyMessage++;
			  for (int i = 0; i < message.size(); i++) {
				  cout << "---------------------------" << endl;
				  cout << "****message is: " << message[i] << endl;
				  cout << "---------------------------" << endl;

				  //kernel->msg_queue.pop();//Arana :clear message in kernel pool
			  }
			  kernel->mach_ports[portNumber].clearMessageV();
			  cout << "DD: now timesEmptyMessage=" << timesEmptyMessage << endl;

			  kernel->currentThread->Yield();
		  }


		  /* Modify return point */
		  {
			  /* set previous programm counter (debugging only)*/
			  kernel->machine->WriteRegister(PrevPCReg, kernel->machine->ReadRegister(PCReg));

			  /* set programm counter to next instruction (all Instructions are 4 byte wide)*/
			  kernel->machine->WriteRegister(PCReg, kernel->machine->ReadRegister(PCReg) + 4);

			  /* set next programm counter for brach execution */
			  kernel->machine->WriteRegister(NextPCReg, kernel->machine->ReadRegister(PCReg) + 4);
		  }
		  return;

		  ASSERTNOTREACHED();
	  }
	  break;



	 // case SC_Halt: {
		//  DEBUG(dbgSys, "Shutdown, initiated by user program.\n");

		//  SysHalt();
	 // }
  //        break;
  //        
		//case SC_Add: {
		//	DEBUG(dbgSys, "Add " << kernel->machine->ReadRegister(4) << " + " << kernel->machine->ReadRegister(5) << "\n");

		//	/* Process SysAdd Systemcall*/
		//	int result;
		//	result = SysAdd(/* int op1 */(int)kernel->machine->ReadRegister(4),
		//		/* int op2 */(int)kernel->machine->ReadRegister(5));

		//	DEBUG(dbgSys, "Add returning with " << result << "\n");
		//	/* Prepare Result */
		//	kernel->machine->WriteRegister(2, (int)result);
		//} 
  //        break;
  //        
		//case SC_Write: {
		//	//an
		//	int result1;
		//	result1 = AnWrite((char*)kernel->machine->ReadRegister(4), (int)kernel->machine->ReadRegister(5));
		//	//printf("Write system call made by %s\n", kernel->currentThread->getName());
		//	kernel->machine->WriteRegister(2, (int)result1);

		//}
		//	break;

		case SC_Exit: {
			printf("Exit system call made by %s\n", kernel->currentThread->getName());
			kernel->currentThread->Finish();
		}
          break;
  //        
		//case SC_Exec: {
		//	addrAn = (int)kernel->machine->ReadRegister(4);
		//	sizeAn = 0;
		//	//char* instruction=new char(100);
		//	char* instruction = (char*)malloc(sizeof(char) * 100);
		//	while (kernel->machine->ReadMem(addrAn, 1, &value))
		//	{
		//		if ((char)value == '\0')
		//		{
		//			break;
		//		}

		//		instruction[sizeAn] = (char)value;
		//		sizeAn++;
		//		addrAn++;
		//	}
		//	Thread* AnThread = new Thread(instruction);
		//	AnThread->Fork((VoidFunctionPtr)RunUserProgram, (void*)instruction);
		//
		//}
		//	break;
        default:
          cerr << "Unexpected system call " << type << "\n";
          break;
      }
      break;	
	default:
      cerr << "Unexpected user mode exception" << (int)which << "\n";
      break;
  }
  
  /* Modify return point */
  {
    /* set previous programm counter (debugging only)*/
    kernel->machine->WriteRegister(PrevPCReg, kernel->machine->ReadRegister(PCReg));
    
    /* set programm counter to next instruction (all Instructions are 4 byte wide)*/
    kernel->machine->WriteRegister(PCReg, kernel->machine->ReadRegister(PCReg) + 4);
    
    /* set next programm counter for brach execution */
    kernel->machine->WriteRegister(NextPCReg, kernel->machine->ReadRegister(PCReg)+4);
  }
}
